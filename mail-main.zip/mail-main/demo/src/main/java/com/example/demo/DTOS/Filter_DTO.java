package com.example.demo.DTOS;

public class Filter_DTO {

    public String Sender;
    public String receiver;
    public String subject;
    public String directory;
}
