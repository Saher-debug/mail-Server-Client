package com.example.demo.DTOS;

public class Folder_DTO {
    public String email;
    public String name;
    public String oldName;
}
