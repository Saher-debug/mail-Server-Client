package com.example.demo.DTOS;

public class Sort_DAO {
    public String sortField;
    public boolean isAsc;
    public String id;
}
