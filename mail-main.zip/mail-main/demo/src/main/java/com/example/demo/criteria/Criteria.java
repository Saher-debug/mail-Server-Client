package com.example.demo.criteria;

import com.example.demo.entity.Message;

import java.util.List;

public interface Criteria {
    public List<Message> meetCriteria();
}
