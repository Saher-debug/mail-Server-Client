import './App.css';
import LoginPage from './Log in/LoginPage';
import MainPage from './MainPage/MainPage';
const App = () => {
  
  return (
    <LoginPage />
        // <MainPage></MainPage>
  );
};
export default App;